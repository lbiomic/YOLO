# gell_app_analysis > 2022-12-14 12:36pm
https://universe.roboflow.com/lbiomic-laboratorio-de-biotecnologia-microbiana/gell_app_analysis

Provided by a Roboflow user
License: CC BY 4.0

